package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ViewFlipper;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.flipersam);

        Button btn_back, btn_next,btn_start,btn_stop;
        final ViewFlipper vFlipper;

        btn_back = (Button)findViewById(R.id.btn_back);
        btn_next = (Button)findViewById(R.id.btn_next);
        btn_start = (Button)findViewById(R.id.btn_start);
        btn_stop = (Button) findViewById(R.id.btn_stop);

        vFlipper = (ViewFlipper)findViewById(R.id.scrollView);
        vFlipper.setFlipInterval(1000);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vFlipper.showPrevious();
            }
        });

        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vFlipper.showNext();
            }
        });

        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vFlipper.startFlipping();
            }
        });

        btn_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vFlipper.stopFlipping();
            }
        });



    }
}
